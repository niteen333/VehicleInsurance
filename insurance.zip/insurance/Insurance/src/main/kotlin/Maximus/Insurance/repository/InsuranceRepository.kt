package Maximus.Insurance.repository

import Maximus.Insurance.model.Insurance
import Maximus.Insurance.model.Vehicle
import org.springframework.data.mongodb.repository.ReactiveMongoRepository

interface InsuranceRepository: ReactiveMongoRepository<Insurance, String> {

}